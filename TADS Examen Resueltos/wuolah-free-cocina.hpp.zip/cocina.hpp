#include "lista_enla.h"
#include <iostream>

struct Mueble {
    double distancia;
    double ancho;
};

class Cocina {
private:
    typedef Lista<Mueble>::posicion pos;
    Lista<Mueble> cocina;
    double longitud;
    unsigned n_muebles;
    pos buscar(const Mueble& m);
public:
    Cocina(double l) : longitud(l), n_muebles(0) {}
    bool puedeColocarse(const Mueble& m);
    void colocar(const Mueble& m, double pos);
    const Mueble& m_iesimo(pos x);
    void eliminar_iesimo();
    void mover_mueble();
    ~Cocina() {}
};

pos Cocina::buscar(const Mueble& m)
{
    pos x = cocina.primera();

    while(x != cocina.fin())
    {
        if(m.distancia == cocina.elemento(x).distancia and
           m.ancho == cocina.elemento(x).ancho)
            return x;
        x = cocina.siguiente(x);
    }
}

pos Cocina::puedeColocarse(const Mueble& m)
{
    assert(m.longitud < longitud);

    pos x = cocina.primera();

    if(n_muebles == 0)
        return x;
    else
        while(x != cocina.fin())
        {
            if(cocina.elemento(x).distancia + cocina.elemento(x).ancho
               <= m.distancia and m.distancia + m.ancho
               <= cocina.siguiente(x).elemento(x).distancia)
                return x;

            x = cocina.siguiente(x);
        }
    return NULL;
}

void Cocina::colocar(const Mueble& m)
{
    pos x = puedeColocarse(m);

    if(x != NULL) {
        cocina.insertar(m, x);
        ++n_muebles;
    }
    else
        cout << "no se puede colocar el mueble" << endl;
}

const Mueble& Cocina::mueble_iesimo(pos x)
{
    pos i = cocina.buscar(cocina.elemento(x));

    if(i != cocina.fin())
        return cocina.elemento(x);
}

void Cocina::eliminar_iesimo(pos x)
{
    pos i = cocina.buscar(cocina.elemento(x));

    if(i != cocina.fin()) {
        cocina.eliminar(x);
        --n_muebles;
    }
}

void Cocina::mover_iesimo(pos x)
{
    pos i = cocina.buscar(cocina.elemento(x));

    if(i != cocina.fin())
        if(x == cocina.primera())
            cocina.elemento(x).distancia = 0;
        else
            cocina.elemento(x).distancia -=
                (cocina.anterior(x).distancia + cocina.anterior(x).ancho);

}
