#ifndef CONSULTORIO_H_
#define CONSULTORIO_H_

#include <iostream.h>
#include <string>
#include <cassert>
#include "Cola.h"
#include "Lista.h"

typedef Lista<Medico>::posicion posi;


struct Paciente{
	int ss; 
	string Nombre;
};

struct Medico{
	int id;
	Cola<Paciente> espera;
};

class Consultorio{
	public:
		Consultorio();
		void AltaMedico(Medico&);
		void BajaMedico(Medico&);
		void PacienteEspera(const Paciente&, Medico&);
		const Paciente& TurnoPaciente(const Medico&);
		void AtenderPaciente(Medico&);
		bool ListaEspera(const Medico&); // No hay pacientes = false

	private:
		Lista<Medico> medicos;
};

bool operator ==(const Medico& m1, const Medico& m2){
	return (m1.id == m2.id);
}

void Consultorio::AltaMedico(Medico& m){
	assert(medicos.buscar(m) == medicos.fin());
	posi = medicos.fin();
	medicos.insertar(m, posi);
}

void Consultorio::BajaMedico(Medico& m){
	assert(medicos.buscar(m) != medicos.fin());
	posi = medicos.buscar(m);
	medicos.eliminar(posi);
}


void Consultorio::PacienteEspera(const Paciente& p, Medico& m){
	assert(medicos.buscar(m) != medicos.fin());
	assert(!m.espera.llena());
	m.espera.push(p);
}

const Paciente& Consultorio::TurnoPaciente(const Medico& m){
	assert(medicos.buscar(m) != medicos.fin());
	assert(!m.espera.vacia());
	return m.espera.frente();
}

void Consultorio::AtenderPaciente(Medico& m){
	assert(medicos.buscar(m) != medicos.fin());
	assert(!m.espera.vacia());
	m.espera.pop();
}

bool Consultorio::ListaEspera(const Medico& m){
	assert(medicos.buscar(m) != medicos.fin());
	return !m.espera.vacia();
}
#endif