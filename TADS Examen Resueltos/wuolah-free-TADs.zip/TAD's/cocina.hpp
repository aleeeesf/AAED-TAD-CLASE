#ifndef COCINA_H_
#define COCINA_H_

#include <iostream>
#include <cassert>
#include "Lista.h"

typedef Lista<Mueble>::posicion posicion;

class Cocina{
	public:
		Cocina(double);
		bool puedeColocarse(Mueble&, posicion);
		void addMueble(Mueble&, posicion);
		Mueble& mueble(posicion);
		void eliminarMueble(posicion);
		void moverMueble(posicion);
		~Cocina();
	private:
		double longitud;
		struct Mueble{ 
			double izq, der; //izq = esquina izquierda a pared y der = anchura mueble.
		};
		Lista<Mueble> pared;
};

Cocina::Cocina(double lon){
	assert(lon > 0);
	longitud = lon;
}

bool Cocina::puedeColocarse(Mueble& m, posicion pos){
	double espacio;

	if(pos == pared.primera())
		espacio = longitud - pared.elemento(siguiente(pos)).izq + pared.elemento(siguiente(pos)).der;
	else if(pos == pared.anterior(fin()))
		espacio = pared.elemento(anterior(pos)).izq;
	else
		espacio = (pared.elemento(siguiente(pos)).izq + pared.elemento(siguiente(pos)).der) - pared.elemento(anterior(pos)).der;
	
	return m.anchura <= espacio;
}

void Cocina::addMueble(Mueble& m, posicion pos){
	assert(puedeColocarse(m,pos));
	pared.insertar(m, pos);
}

Mueble& Cocina::mueble(posicion pos){
	assert(pos != pared.fin());
	return pared.buscar(pos);
}

void Cocina::eliminarMueble(posicion pos){
	assert(pos != pared.fin());
	pared.eliminar(pos);
}

void Cocina::moverMueble(posicion pos){
	assert(pos != pared.fin());

	if(pared.siguiente(pos) != pared.fin())
		pared.elemento(pos).izq = pared.elemento(siguiente(pos)).izq + pared.elemento(siguiente(pos)).der;
	else
	{
		if(pared.elemento(pos).izq != 0)
			pared.elemento(pos).izq = 0;
		else
			cout << "El mueble ya esta pegado" << endl;
	}
}

#endif