#ifndef COCINA_HPP
#define COCINA_HPP

#include "listapseudoestatica.h"
#include "string.h"

struct Palabra
{
	string ing;
	Lista<string> espaniol;
};

typedef Lista<string>::posicion pos;

class Diccionario
{
public:
	Diccionario(){}
	void insertarTraduccion(Palabra& i, const string& e);
	void eliminarTraduccion(Palabra& i, const string& e);
	Lista<string> mostrarTraducciones(const Palabra& i);
	~Diccionario(){}
private:
	Lista<Palabra> ingles;
};

void Diccionario::insertarTraduccion(Palabra& i, const string& e)
{
	pos x = ingles.buscar(i);
	assert(x != ingles.fin());
	Lista<Palabra>::posicion final;
	final = ingles.elemento(x).spaniol.fin();
	ingles.elemento(x).insertar(e, final);
}

void Diccionario::eliminarTraduccion(Palabra& i, const string& e)
{
	pos x = ingles.buscar(i);
	pos y = ingles.elemento(x).espaniol.buscar(e);
	assert(x != ingles.fin() && y!=ingles.elemento(x).espaniol.fin());
	ingles.elemento(x).espaniol.eliminar(y);
}

Lista<string> mostrarTraducciones(const Palabra& i)
{
	Lista<Palabra>::posicion posi;
	posi = ingles.buscar(i);
	assert(posi != ingles.fin());

	return dic.elemento(posi).spa;
}

#endif