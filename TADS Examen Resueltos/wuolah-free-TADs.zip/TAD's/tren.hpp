#ifndef TREN_HPP
#define TREN_HPP

#include "pilaenlazada.h"
#include <iostream>

class Tren
{
public:
	Tren(){}
	void desplazarIzq();
	void desplazarDcha();
	void eliminarVagonActivo();
	void insertarVagonActivo(const Vagon& vagon);
	const Vagon& vagonActivo() const noexcept{return vagonActivo;}
	bool trenVacio();
	~Tren();
private:
	struct vagon{};
	pila<Vagon> p1;
	pila<Vagon> p2;
	Vagon vagonActivo = p1.tope();
};

void Tren::desplazarIzq()
{
	assert(!trenVacio())
	if(!p2.vacia())
	{
		p1.push(p2.tope());
		p2.pop();
		vagonActivo = p1.tope();
	}
	else
		cout << "No hay vagon que mover" << endl;
}

void Tren::desplazarDcha()
{
	assert(!trenVacio())
	if(!p1.vacia())
	{
		p2.push(p1.tope());
		p2.pop();
		vagonActivo = p1.tope();
	}
	else
		cout << "No hay vagon que mover" << endl;
}

void Tren::eliminarVagonActivo()
{
	assert(!trenVacio() && !p1.vacia())
	p1.pop();
	if(!p2.vacia())
	{
		p1.push(p2.tope());
		p2.pop();
		vagonActivo = p1.tope();
	}
	else
	{
		if(!p1.vacia())
			vagonActivo = p1.tope();
		else
		cout << "El tren ha quedado vacio" << endl;
	}
}

void Tren::insertarVagonActivo(const Vagon& v)
{
	p1.push(v);
	vagonActivo = p1.tope();
}

bool Tren::trenVacio() noexcept
{
	if(p1.vacia() && p2.vacia())
		return true;
	else
		return false;
}

#endif // TREN_HPP