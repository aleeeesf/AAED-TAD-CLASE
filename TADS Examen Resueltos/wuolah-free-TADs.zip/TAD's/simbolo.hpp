#ifndef SIMBOLO_H
#define SIMBOLO_H

#include <cassert>
#include <ostream>
#include "pila.h"
using namespace std;

enum Trazo {I, D, S, B};
class Simbolo
{
	friend ostream& operator<<(ostream& o, Simbolo s);
public:
	Simbolo(): numTrazos(0), trazos(Pila<Trazo>()){}
	Simbolo(Pila<Trazo>&& ts);
	void insertarTrazo(Trazo t);
	void eliminarTrazos(size_t n);
	Simbolo simetriaX() const;
	Simbolo simetriaY() const;
	Simbolo simetriaXY() const;
private:
	size_t numTrazos;
	Pila<Trazo> trazos;
};

Simbolo::Simbolo(Pila<Trazo>&& ts)
{
	trazos = ts;
	numTrazos = 0;
	while (!ts.vacia())
	{
		++numTrazos;
		ts.pop();
	}
}

inline void Simbolo::insertarTrazo(Trazo t)
{
	trazos.push(t);
}

void Simbolo::eliminarTrazos(size_t n)
{
	assert(!trazos.vacia() && n <= numTrazos);
	for (size_t i=0; i<n; ++i)
		trazos.pop();
}

Simbolo Simbolo::simetriaX() const
{
	Pila<Trazo> copia = trazos;
	Pila<Trazo> intercambio;
	Pila<Trazo> dev;
	while (!copia.vacia())
	{
		Trazo aux;
		switch (aux = copia.tope())
		{
		case (I):aux = D; break;
		case(D):aux = I; break;
		default: break;
		}
	intercambio.push(aux);
	copia.pop();
	}
	while (!intercambio.vacia())
	{
		dev.push(intercambio.tope());
		intercambio.pop();
	}
	return dev;
}

Simbolo Simbolo::simetriaY() const
{
Pila<Trazo> copia = trazos;
	Pila<Trazo> intercambio;
	Pila<Trazo> dev;
	while (!copia.vacia())
	{
		Trazo aux;
		switch (aux = copia.tope())
		{
		case (S):aux = B; break;
		case(B):aux = S; break;
		default: break;
		}
	intercambio.push(aux);
	copia.pop();
	}
	while (!intercambio.vacia())
	{
		dev.push(intercambio.tope());
		intercambio.pop();
	}
	return dev;
}

Simbolo Simbolo::simetriaXY() const
{
Pila<Trazo> copia = trazos;
	Pila<Trazo> intercambio;
	Pila<Trazo> dev;
	while (!copia.vacia())
	{
		Trazo aux;
		switch (aux = copia.tope())
		{
		case (I):aux = D; break;
		case(D):aux = I; break;
		case (S):aux = B; break;
		case(B):aux = S; break;
		default: break;
		}
	intercambio.push(aux);
	copia.pop();
	}
	while (!intercambio.vacia())
	{
		dev.push(intercambio.tope());
		intercambio.pop();
	}
	return dev;
}

ostream& operator<<(ostream& o, Simbolo s)
{
	while (!s.trazos.vacia())
	{
		switch (s.trazos.tope())
		{
		case I:o << 'I';break;
		case D:o << 'D';break;
		case S:o << 'S';break;
		case B:o << 'B';break;
		}
	s.trazos.pop();
	}
	return o;	
}

#endif