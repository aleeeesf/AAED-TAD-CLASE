#ifndef HOSPITAL_HPP
#define HOSPITAL_HPP

#include "listapseudoestatica.h"
#include <string>

struct Paciente
{
	string s_cod;
	unsigned u_grav;
};

typedef Lista<Paciente>::posicion pos;

class Hospital{
public:
	explicit Hospital(const unsigned& tamUCI, const unsigned& tamPlanta): tamaMaxUCI(tamUCI), tamaMaxPlanta(tamPlanta) {}
	void ingreso(const Paciente& p);
	void darAlta(const Paciente& p);
	void muerte(const Paciente& p);
	const pos menosGraveUCI();
	const pos menosGravePlanta();
	const unsigned n_UCI() noexcept;
	const unsigned n_Planta() noexcept;
	const Lista<Paciente>& UCI() noexcept;
	const Lista<Paciente>& Planta() noexcept;
	const unsigned PacientesGravedad(unsigned g) noexcept;
	~Hospital(){}
private:
	Lista<Paciente> UCI;
	Lista<Paciente> Planta;

	unsigned tamaMaxPlanta, tamaMaxUCI;
};

void Hospital::ingreso(const Paciente& p)
{
	pos x;
	Lista<Paciente>::posicion finUCI = UCI.fin();
	Lista<Paciente>::posicion finplanta = Planta.fin();
	if(p.u_grav > 0 && p.u_grav <= 5)
		if(n_UCI() < tamaMaxUCI)
			UCI.insertar(p, finUCI);
		else
		{
			x = menosGraveUCI();
			Paciente menosGraveUCI = UCI.elemento(x);

			if(n_Planta() < tamaMaxPlanta)
				Planta.insertar(menosGraveUCI, x);
			else
			{
				pos y = menosGravePlanta();
				Paciente menosGravePlanta = Planta.elemento(y);
				darAlta(menosGravePlanta);
				Planta.insertar(menosGraveUCI, finplanta);
			}
			UCI.insertar(p, finUCI);
		}
	else if(p.u_grav > 5 && p.u_grav <=10)
		if(n_Planta() < tamaMaxPlanta)
			Planta.insertar(p, finplanta);
		else
		{
			pos y = menosGravePlanta();
			Paciente menosGravePlanta = Planta.elemento(y):
			darAlta(menosGravePlanta);
			Planta.insertar(p, finplanta);

		}
	else
		muerte(p);
}

void Hospital::darAlta(const Paciente& p)
{
	assert(!Planta.vacia())
	Lista<Paciente>::posicion elto = Planta.buscar(p);
	assert(elto != Planta.fin());
	cout << "El paciente con codigo " << p.s_cod << " ha sido dado de alta." << endl;
	Planta.eliminar(elto);
		
}

void Hospital::muerte(const Paciente& p)
{
	assert(!Planta.vacia() && !UCI.vacia());
	Lista<Paciente>::posicion eltoPlanta = Planta.buscar(p);
	Lista<Paciente>::posicion eltoUCI = UCI.buscar(p);

	assert(eltoPlanta != Planta.fin() && eltoUCI != UCI.fin())

	if(p.u_grav > 0 && p.u_grav <= 5)
	{
		cout << "El paciente con codigo " << p.s_cod << " ha fallecido." << endl;
		UCI.eliminar(eltoUCI);
	}
	else if(p.u_grav > 5 && p.u_grav <=10)
	{
		cout << "El paciente con codigo " << p.s_cod << " ha fallecido." << endl;
		Planta.eliminar(eltoPlanta);

	}
	else
	    cout << "No se encuentra el paciente" << endl;
}

const pos Hospital::menosGraveUCI()
{
	assert(!UCI.vacia())
	unsigned gravedad = UCI.elemento(UCI.primera()).u_grav;
	Lista<Paciente>::posicion i = UCI.primera();
	for (pos x = UCI.siguiente(UCI.primera()); x!= UCI.fin(); x = UCI.siguiente(x))
	{
		if(UCI.elemento(x).u_grav < gravedad)
			gravedad = UCI.elemento(x).u_grav;
			i = x;
	}
	return i;
}

const pos Hospital::menosGravePlanta()
{
	assert(!Planta.vacia())
	unsigned gravedad = Planta.elemento(Planta.primera()).u_grav;
	Lista<Paciente>::posicion i = Planta.primera();
	for (pos x = Planta.siguiente(Planta.primera()); x!= Planta.fin(); x = Planta.siguiente(x))
	{
		if(Planta.elemento(x).u_grav < gravedad)
			gravedad = Planta.elemento(x).u_grav;
			i = x;
	}
	return i;
}

const unsigned n_UCI() noexcept
{
	Lista<Paciente>::posicion x = UCI.primera();
	unsigned n_pacientes = 0;
	while(x != UCI.fin())
	{
		++n_pacientes;
		x = UCI.siguiente(x);
	}
	return n_pacientes;
}

const unsigned n_Planta() noexcept
{
	Lista<Paciente>::posicion x = Planta.primera();
	unsigned n_pacientes = 0;
	while(x != Planta.fin())
	{
		++n_pacientes;
		x = Planta.siguiente(x);
	}
	return n_pacientes;
}

const Lista<Paciente>& UCI() noexcept
{
	assert(!UCI.vacia());
	return UCI;
}

const Lista<Paciente>& Planta() noexcept
{
	assert(!Planta.vacia());
	return Planta;
}

const unsigned Hospital::PacientesGravedad(unsigned g) noexcept
{
	Lista<Paciente>::posicion x, y;
	unsigned n = 0;

	x = UCI.primera();
	y = Planta.primera();

	while(x != UCI.fin())
	{
		if(UCI.elemento(x).u_grav == g)
			++n;
		x = UCI.siguiente(x);
	}
	while(y != Planta.fin())
	{
		if(Planta.elemento(x).u_grav == g)
			++n;
		x = Planta.siguiente(x);
	}
	return n;
}


#endif // HOSPITAL_HPP